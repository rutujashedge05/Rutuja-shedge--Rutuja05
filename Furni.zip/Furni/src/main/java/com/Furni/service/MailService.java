package com.Furni.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.ws.mime.MimeMessage;

import com.Furni.bean.Email;

import jakarta.mail.MessagingException;


@Service
public class MailService {

	@Autowired
	private JavaMailSender mailsender;
	
	@Value("${spring.mail.username}")
	private String fromMail="rutushedge05@gmail.com";
	public void sendmail(String mail, Email email) {
	    jakarta.mail.internet.MimeMessage mimeMessage = mailsender.createMimeMessage();
	    MimeMessageHelper helper;
	    try {
	        helper = new MimeMessageHelper(mimeMessage, true);
	        helper.setFrom(fromMail);
	        helper.setSubject(email.getSubject());
	        helper.setText(email.getMessage(), true); // Set the message to HTML
	        helper.setTo(mail);
	        mailsender.send(mimeMessage);
	    } catch (MessagingException e) {
	        // Handle exception
	    }
	}
}

