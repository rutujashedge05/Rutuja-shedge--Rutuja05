package com.Furni.bean;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity 

public class Cart {
 
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Id
  private int id;
  private String product_name; 
  private String product_image;
  private int product_price; 
  private int product_quantity; 
  private int P_id;
  private int u_id; 
  private int total_price;
  
	public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getProduct_name() {
	return product_name;
}
public void setProduct_name(String product_name) {
	this.product_name = product_name;
}
public String getProduct_image() {
	return product_image;
}
public void setProduct_image(String product_image) {
	this.product_image = product_image;
}
public int getProduct_price() {
	return product_price;
}
public void setProduct_price(int product_price) {
	this.product_price = product_price;
}
public int getProduct_quantity() {
	return product_quantity;
}
public void setProduct_quantity(int product_quantity) {
	this.product_quantity = product_quantity;
}
public int getP_id() {
	return P_id;
}
public void setP_id(int p_id) {
	P_id = p_id;
}
public int getU_id() {
	return u_id;
}
public void setU_id(int u_id) {
	this.u_id = u_id;
}
public int getTotal_price() {
	return total_price;
}
public void setTotal_price(int total_price) {
	this.total_price = total_price;
}
	

 }
 