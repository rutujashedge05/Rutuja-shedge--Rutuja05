package com.Furni.Configuration;

import java.util.Random;

import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;


@Service
public class OtpService {

	@Value("${twilio.phone.number}")
    private String fromPhoneNumber;

    public String generateOtp() {
        Random random = new Random();
        int otp = 100000 + random.nextInt(900000); // Generate 6-digit OTP
        return String.valueOf(otp);
    }

    public void sendOtp(String toPhoneNumber, String otp) {
        Message.creator(
                new PhoneNumber(toPhoneNumber),
                new PhoneNumber(fromPhoneNumber),
                "Your OTP code is: " + otp
        ).create();
    }

}
