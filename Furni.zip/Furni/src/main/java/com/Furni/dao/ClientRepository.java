package com.Furni.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.Furni.bean.Client;



@Repository
public interface ClientRepository extends CrudRepository<Client, Integer>{

}
