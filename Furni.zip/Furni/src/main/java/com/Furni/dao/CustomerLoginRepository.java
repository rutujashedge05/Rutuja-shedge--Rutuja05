package com.Furni.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.Furni.bean.Customerlogin;

@Repository
public interface CustomerLoginRepository extends CrudRepository<Customerlogin, Integer> {

}
