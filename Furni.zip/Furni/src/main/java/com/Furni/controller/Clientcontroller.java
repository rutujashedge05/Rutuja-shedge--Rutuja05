package com.Furni.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.Furni.bean.Client;
import com.Furni.bean.Contact;
import com.Furni.bean.Customerlogin;
import com.Furni.bean.Email;
import com.Furni.Configuration.OtpService;
import com.Furni.bean.AddProduct;
import com.Furni.bean.Cart;
/*import com.Furni.bean.Cart;*/
import com.Furni.dao.AddProductRepository;
import com.Furni.dao.CartRepository;
/*import com.Furni.dao.CartRepository;*/
import com.Furni.dao.ClientRepository;
import com.Furni.dao.ContactRepository;
import com.Furni.dao.CustomerLoginRepository;
import com.Furni.service.MailService;
import com.razorpay.Order;
import com.razorpay.RazorpayClient;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@Controller
public class Clientcontroller {
	
	@Autowired
	ClientRepository cl;
	
	@Autowired
	ContactRepository co;
	
	@Autowired
	 AddProductRepository apd; 
	
	@Autowired
	CustomerLoginRepository clr;

	
	  @Autowired CartRepository cr;
	 
	  
	  
	 @RequestMapping("/Demo") 
	  public String Demo() {
	  
		  return"Demo";
	  }
	
	@RequestMapping("/index")
	public String index() {
		
		return"index";
	}
	
	@RequestMapping("/about")
	public String about() {
		
		return"about";
	}
	
	@RequestMapping("/services")
	public String services() { 
		
		return"services";
	}
	
	@RequestMapping("/blog")
	public String blog() {
		
		return"blog";
	}
	
	 @RequestMapping("/thankyou") 
	  public String thankyou() {
	  
		  return"thankyou";
	  }
	
	@RequestMapping("/contact")
	public String contact() {
		
		return"contact";
	}
	
	@RequestMapping("/contactregister")
	public String contactregister(Contact o) {
		
		co.save(o);
		
		
		return "redirect:/index";
	}
	
	@RequestMapping("/login")
	public String login() {
		
		return"login";
	}
	
	@RequestMapping("/clientlogin")
	public String clientlogin( Client c,HttpServletRequest req,HttpServletResponse res) {
		
		List<Client> list=(List) cl.findAll();
		
			

			String name="admin@123gmail.com";
			String password="admin123";
			
			for(Client c1:list) {
				
				if(c.getEmail().equals(name)&&c.getPassword().equals(password)) {
					
					return "index2";
				}	
			
		if(c.getEmail().equals(c1.getEmail())&& (c.getPassword().equals(c1.getPassword()))){
			Optional op = cl.findById(c1.getId());
			Client client = (Client)op.get();
			
		HttpSession session=req.getSession();
		session.setAttribute("loginname",c1.getFirstname());
		session.setAttribute("showlogindata", client);
			
		 System.out.println(list);
			
			Customerlogin cl = new Customerlogin();
			cl.setId(c1.getId());
			cl.setFirstname(c1.getFirstname());
			cl.setLastname(c1.getLastname());
			cl.setAddress(c1.getAddress());
			cl.setMobileNumber(c1.getMobileNumber());
			cl.setEmail(c1.getEmail());
			cl.setPassword(c1.getPassword());
			cl.setConfirmpassword(c1.getConfirmpassword());
			cl.setDOB(c1.getDOB());
			
			clr.save(cl);
			return"redirect:/index";
		}
		}
		return"redirect:/register";
	}
	
	@RequestMapping("/Logout")
	public String Logout(HttpServletRequest req,HttpServletResponse res) {
		
		HttpSession session=req.getSession();
		session.removeAttribute("loginname");
		return"redirect:/index";
	}
	@RequestMapping("/register")
	public String register() {
		
		return"register";
	}
	
	
	@RequestMapping("/index2")
	public String index2() {
		
		return"index2";
	}
	
	@RequestMapping("/forgotpassword")
	public String forgotpassword() {
		
		return"forgotpassword";
	}
	
	@RequestMapping("/reset")
	public String reset(Client c,HttpServletRequest req,HttpServletResponse res) {
		List<Client> list=(List) cl.findAll();
		for(Client c1:list) {
		
			if(c1.getEmail().equals(c.getEmail())) {
				
			c1.setPassword(c.getPassword());
			
			cl.save(c1);
			}
			else {
				
				HttpSession session=req.getSession();
				session.removeAttribute("loginname");
			}
		
		}
		return "login";
	}
	
	  @RequestMapping("/AddProduct") 
	  public String AddProduct() {
	  
		  return"AddProduct";
	  }
	  
	  @RequestMapping("/dataregister")
	  public String dataregister(AddProduct ap) { 
		  
		apd.save(ap); 
		return"index2"; }
	 
	
	@RequestMapping("/manageproduct")
	public ArrayList manageproduct(HttpServletRequest req, HttpServletResponse res) {
	ArrayList list = new ArrayList();
	
	for(AddProduct ct: apd.findAll()) 
	{
			list.add(ct);
		}

		HttpSession session = req.getSession();
		session.setAttribute("showdata",list);
		
		return list;
	}
		
	@RequestMapping("/UserDelete")
	public String datadelete(AddProduct t) {

		apd.deleteById(t.getId());

	return "redirect:/manageproduct";
}


		@RequestMapping("/update")
			public String update(AddProduct t, HttpServletRequest req, HttpServletResponse res) {
			HttpSession session = req.getSession();
			session.setAttribute("oldData", t);
			return "update";
			
			
		}
	@RequestMapping ("/updatedata")
	public String updatedata(  AddProduct t) {
		Optional op = apd.findById(t.getId());
		
		if(op.isPresent()) {
			
			AddProduct the = (AddProduct) op.get();
			
			the.setId(t.getId());
			the.setProductname(t.getProductname());
			the.setProductQuantity(t.getProductQuantity());
			the.setProduct_image(t.getProduct_image());
			the.setProductPrice(t.getProductPrice());
			the.setBillingAddress(t.getBillingAddress());
			
			apd.save(the);
			
		}
		return "redirect:/manageproduct";
	}
	
	@RequestMapping("/manageuser")
	public ArrayList manage_user(HttpServletRequest req, HttpServletResponse res) {
	ArrayList list = new ArrayList();
	
	for(Client c: cl.findAll()) 
	{
			list.add(c);
		}

		HttpSession session = req.getSession();
		session.setAttribute("manage_user_showdata",list);
		
		return list;
	}
	
@RequestMapping("/userlogindata")
	
	
	public ArrayList Userlogindata(HttpServletRequest req, HttpServletResponse res) {
	ArrayList list = new ArrayList();
	
	for(Customerlogin cl: clr.findAll()) 
	{
			list.add(cl);
		}
	System.out.println(list);

		HttpSession session = req.getSession();
		session.setAttribute("loginshowdata",list);
		
		return list;
	}
	
	@RequestMapping("/checkout")
	public String checkout() {
	
		return"checkout";
}
	

//  @RequestMapping("/cart") public ArrayList cart(HttpServletRequest
//  req,HttpServletResponse res) {
//  
//  
//  ArrayList list = new ArrayList();
//  
//  for(Cart c :cr.findAll()) {
//  
//  list.add(c);
//  
//  
//  } HttpSession session = req.getSession();
//  session.setAttribute("usercartdata",list);
//  
//  
//  return list; }
// 
	
	/*
	 * @RequestMapping("/addtocart") public String addtocart(Product p,user
	 * u,HttpServletRequest req,HttpServletResponse res) { int count=1;
	 * 
	 * HttpSession session = req.getSession();
	 * session.setAttribute("cartproductdata", p); session.setAttribute("userdata",
	 * u);
	 * 
	 * List<Cart>list= (List)cr.findAll(); boolean watchExists = false; for(Cart c1
	 * :list) { if(c1.getU_id() == u.getId()&&c1.getP_id()== p.getP_id()) {
	 * 
	 * count = c1.getWatch_quantity()+1;
	 * c1.setWatch_quantity(c1.getWatch_quantity()+1);
	 * 
	 * 
	 * cr.save(c1); watchExists = true; break;
	 * 
	 * }
	 * 
	 * }
	 * 
	 * if(!watchExists) { Cart c = new Cart(); c.setP_id(p.getP_id());
	 * c.setWatch_name(p.getP_name()); c.setWatch_image(p.getP_image());
	 * c.setWatch_price(p.getP_price()); c.setU_id(u.getId());
	 * c.setWatch_quantity(1);
	 * 
	 * 
	 * cr.save(c); } return "redirect:/cart";
	 * 
	 * }
	 */
	
	@RequestMapping("/shop")
	public ArrayList shop(HttpServletRequest req, HttpServletResponse res) {
	ArrayList list = new ArrayList();
	
	for(AddProduct ct: apd.findAll()) 
	{
			list.add(ct);
		}

		HttpSession session = req.getSession();
		session.setAttribute("showdata",list);
		
		return list;
	}
	

	
	@RequestMapping ("/dataAdd")
	public String dataAdd(  AddProduct t,HttpServletRequest req, HttpServletResponse res) {
		
		HttpSession session = req.getSession();
		session.setAttribute("productss",t);

	return "Productdetailpage";
	}
	 
	 @RequestMapping("/Productdetailpage") 
	  public String Productdetailpage() {
	  
		  return"Productdetailpage";
	  }
	 
	 
	  @RequestMapping ("/dataAddtocart")
		public String dataAddtocart(AddProduct t,HttpServletRequest req, HttpServletResponse res) {
			
		  
		  
			HttpSession session = req.getSession();
			session.setAttribute("productsss",t);

		return "Productdetailpage";
		}
	 
	  @RequestMapping("/showaddtocartdata")
		public String ShowAddtoCart(AddProduct b, Client u, HttpServletRequest req, HttpServletResponse res) {
			int count = 1;
			
			HttpSession session = req.getSession();
			session.setAttribute("CartBookDetails", b);
			session.setAttribute("CartUserDetails", u);
			
			List<Cart> list= (List) cr.findAll();
			boolean bookExists = false;
			for(Cart c1: list) {
				if(c1.getU_id() == u.getId() && c1.getP_id() == b.getId()) {
					count = c1.getProduct_quantity()+1;
					c1.setProduct_quantity(c1.getProduct_quantity()+1);
					cr.save(c1);
					bookExists = true;
		            break;
					
				}			 
			}
			
			if (!bookExists) {
				Cart c = new Cart();
				c.setP_id(b.getId());
				c.setProduct_name(b.getProductname());
				c.setProduct_image(b.getProduct_image());
				c.setProduct_quantity(b.getProductQuantity());
				c.setU_id(b.getId());
				c.setProduct_price(b.getProductPrice());
				
				
				cr.save(c);
			 
			}	
		
			return"Productdetailpage";
		}
	 
	 @RequestMapping("/cart")
		public ArrayList cart(HttpServletRequest req, HttpServletResponse res) {
		ArrayList list = new ArrayList();
		
		for(Cart ca: cr.findAll()) 
		{
				list.add(ca);
				
			}

			HttpSession session = req.getSession();
			session.setAttribute("showdata",list);
			
			
			
			return list;
		}
	 
	 
	@RequestMapping("/delete")
	public String delete(Cart ca) {
  		cr.deleteById(ca.getId());

	return "redirect:/cart";
}
	
	  @Autowired
	    private OtpService otpService;

	    @GetMapping("/showForm")
	    public String showForm() {
	        return "showForm";
	    }

	    @PostMapping("/sendOtp")
	    public String sendOtp(@RequestParam("phoneNumber") String phoneNumber, Model model) {
	        String otp = otpService.generateOtp();
	        otpService.sendOtp(phoneNumber, otp);
	        model.addAttribute("message", "OTP sent to " + phoneNumber);
	        return "index";
	    }
	    

		@RequestMapping("/payment")
		public String payment() {
			return "payment";
		}
	 
		@PostMapping("/createOrder")
		@ResponseBody
		public String create_order(@RequestBody Map<String, Object> data,HttpSession session) throws Exception {


			System.out.println(data);
			int amt=Integer.parseInt(data.get("amount").toString());
			
				var client=new RazorpayClient("rzp_test_wRHAK6wS8MjByN","LI0yDhZN73L8on6qO6WXsSNd");
				JSONObject obj=new JSONObject();
				obj.put("amount", amt*100);
				obj.put("currency", "INR");
				obj.put("receipt", "txn_235425");
				
				Order order=client.orders.create(obj);
				System.out.println(order);
				
				
				return order.toString();
		}
		
		
//		@Autowired
//		MailService mailservice;
//		
//		@RequestMapping("/clientregister")
//		public String clientregister(Client u) {
//			
//			System.out.println(u.getEmail());
//			System.out.println(u.getPassword()+"--------");
//			
//			List<Client> list =  (List) cl.findAll();
//			for(Client u1 : list) {
//				if(u1.getEmail().equals(u.getEmail())) {
//					
//					return "register";
//				}
//			}		
//			if(u.getPassword().equals(u.getConfirmpassword())) {	
//				Email email = new Email();
//				email.setSubject("Welcome to Furni!");
//				email.setMessage("Dear " + u.getFirstname() + ",\n\nThank you for registering with Furni!");
//				mailservice.sendmail(u.getEmail(),email);
//			
//			cl.save(u);
//			return "index";
//			}
//			
//			return "register";
//			
//		}
		
		
		
		
		// registration throw mail
	    @Autowired
	    MailService mailservice;

	    @RequestMapping("/clientregister")
	    public String clientregister(Client u, HttpSession session) {
	        // Check if the email already exists in the database
	        boolean emailExists = false;
	        List<Client> list = (List<Client>) cl.findAll();
	        for (Client u1 : list) {
	            if(u1.getEmail().equals(u.getEmail())) {
	                emailExists = true;
	                break;
	            }
	        }

	        if (emailExists) {
	            // If the email is already registered, set the error message in the session
	            session.setAttribute("errorMessage", "Email already registered.");
	            return "redirect:/register"; // Redirect back to the registration page
	        } else {
	            // If the email is not registered, proceed with registration
	            Email email = new Email();
	            email.setSubject("Welcome to Furni...!");
	           
	            email.setMessage("<!DOCTYPE html>\r\n"
	            		+ "<html xmlns:v=\"urn:schemas-microsoft-com:vml\" xmlns:o=\"urn:schemas-microsoft-com:office:office\" lang=\"en\">\r\n"
	            		+ "\r\n"
	            		+ "<head>\r\n"
	            		+ "	<title></title>\r\n"
	            		+ "	<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">\r\n"
	            		+ "	<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\"><!--[if mso]><xml><o:OfficeDocumentSettings><o:PixelsPerInch>96</o:PixelsPerInch><o:AllowPNG/></o:OfficeDocumentSettings></xml><![endif]--><!--[if !mso]><!-->\r\n"
	            		+ "	<link href=\"https://fonts.googleapis.com/css?family=Oswald\" rel=\"stylesheet\" type=\"text/css\"><!--<![endif]-->\r\n"
	            		+ "	<style>\r\n"
	            		+ "		* {\r\n"
	            		+ "			box-sizing: border-box;\r\n"
	            		+ "		}\r\n"
	            		+ "\r\n"
	            		+ "		body {\r\n"
	            		+ "			margin: 0;\r\n"
	            		+ "			padding: 0;\r\n"
	            		+ "		}\r\n"
	            		+ "\r\n"
	            		+ "		a[x-apple-data-detectors] {\r\n"
	            		+ "			color: inherit !important;\r\n"
	            		+ "			text-decoration: inherit !important;\r\n"
	            		+ "		}\r\n"
	            		+ "\r\n"
	            		+ "		#MessageViewBody a {\r\n"
	            		+ "			color: inherit;\r\n"
	            		+ "			text-decoration: none;\r\n"
	            		+ "		}\r\n"
	            		+ "\r\n"
	            		+ "		p {\r\n"
	            		+ "			line-height: inherit\r\n"
	            		+ "		}\r\n"
	            		+ "\r\n"
	            		+ "		.desktop_hide,\r\n"
	            		+ "		.desktop_hide table {\r\n"
	            		+ "			mso-hide: all;\r\n"
	            		+ "			display: none;\r\n"
	            		+ "			max-height: 0px;\r\n"
	            		+ "			overflow: hidden;\r\n"
	            		+ "		}\r\n"
	            		+ "\r\n"
	            		+ "		.image_block img+div {\r\n"
	            		+ "			display: none;\r\n"
	            		+ "		}\r\n"
	            		+ "\r\n"
	            		+ "		@media (max-width:670px) {\r\n"
	            		+ "\r\n"
	            		+ "			.desktop_hide table.icons-inner,\r\n"
	            		+ "			.social_block.desktop_hide .social-table {\r\n"
	            		+ "				display: inline-block !important;\r\n"
	            		+ "			}\r\n"
	            		+ "\r\n"
	            		+ "			.icons-inner {\r\n"
	            		+ "				text-align: center;\r\n"
	            		+ "			}\r\n"
	            		+ "\r\n"
	            		+ "			.icons-inner td {\r\n"
	            		+ "				margin: 0 auto;\r\n"
	            		+ "			}\r\n"
	            		+ "\r\n"
	            		+ "			.mobile_hide {\r\n"
	            		+ "				display: none;\r\n"
	            		+ "			}\r\n"
	            		+ "\r\n"
	            		+ "			.row-content {\r\n"
	            		+ "				width: 100% !important;\r\n"
	            		+ "			}\r\n"
	            		+ "\r\n"
	            		+ "			.stack .column {\r\n"
	            		+ "				width: 100%;\r\n"
	            		+ "				display: block;\r\n"
	            		+ "			}\r\n"
	            		+ "\r\n"
	            		+ "			.mobile_hide {\r\n"
	            		+ "				min-height: 0;\r\n"
	            		+ "				max-height: 0;\r\n"
	            		+ "				max-width: 0;\r\n"
	            		+ "				overflow: hidden;\r\n"
	            		+ "				font-size: 0px;\r\n"
	            		+ "			}\r\n"
	            		+ "\r\n"
	            		+ "			.desktop_hide,\r\n"
	            		+ "			.desktop_hide table {\r\n"
	            		+ "				display: table !important;\r\n"
	            		+ "				max-height: none !important;\r\n"
	            		+ "			}\r\n"
	            		+ "		}\r\n"
	            		+ "	</style>\r\n"
	            		+ "</head>\r\n"
	            		+ "\r\n"
	            		+ "<body class=\"body\" style=\"background-color: #FFFFFF; margin: 0; padding: 0; -webkit-text-size-adjust: none; text-size-adjust: none;\">\r\n"
	            		+ "	<table class=\"nl-container\" width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" role=\"presentation\" style=\"mso-table-lspace: 0pt; mso-table-rspace: 0pt; background-color: #FFFFFF;\">\r\n"
	            		+ "		<tbody>\r\n"
	            		+ "			<tr>\r\n"
	            		+ "				<td>\r\n"
	            		+ "					<table class=\"row row-1\" align=\"center\" width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" role=\"presentation\" style=\"mso-table-lspace: 0pt; mso-table-rspace: 0pt; background-color: #07071f;\">\r\n"
	            		+ "						<tbody>\r\n"
	            		+ "							<tr>\r\n"
	            		+ "								<td>\r\n"
	            		+ "									<table class=\"row-content stack\" align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" role=\"presentation\" style=\"mso-table-lspace: 0pt; mso-table-rspace: 0pt; background-color: #060e21; color: #000000; background-image: url('https://d1oco4z2z1fhwp.cloudfront.net/templates/default/5201/fashiong-bg2-2.jpg'); background-repeat: no-repeat; width: 650px; margin: 0 auto;\" width=\"650\">\r\n"
	            		+ "										<tbody>\r\n"
	            		+ "											<tr>\r\n"
	            		+ "												<td class=\"column column-1\" width=\"100%\" style=\"mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; padding-top: 5px; vertical-align: top; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;\">\r\n"
	            		+ "													<table class=\"paragraph_block block-1\" width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" role=\"presentation\" style=\"mso-table-lspace: 0pt; mso-table-rspace: 0pt; word-break: break-word;\">\r\n"
	            		+ "														<tr>\r\n"
	            		+ "															<td class=\"pad\" style=\"padding-top:10px;\">\r\n"
	            		+ "																<div style=\"color:#393d47;font-family:'Oswald',Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:11px;letter-spacing:9px;line-height:120%;text-align:center;mso-line-height-alt:13.2px;\">\r\n"
	            		+ "																	<p style=\"margin: 0; word-break: break-word;\"><span style=\"color: #ffffff;\"><strong>&nbsp;WWW.MALEFASHION.COM<br></strong></span></p>\r\n"
	            		+ "																</div>\r\n"
	            		+ "															</td>\r\n"
	            		+ "														</tr>\r\n"
	            		+ "													</table>\r\n"
	            		+ "													<div class=\"spacer_block block-2\" style=\"height:75px;line-height:75px;font-size:1px;\">&#8202;</div>\r\n"
	            		+ "													<table class=\"image_block block-3\" width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" role=\"presentation\" style=\"mso-table-lspace: 0pt; mso-table-rspace: 0pt;\">\r\n"
	            		+ "														<tr>\r\n"
	            		+ "															<td class=\"pad\" style=\"width:100%;padding-right:0px;padding-left:0px;\">\r\n"
	            		+ "																<div class=\"alignment\" align=\"center\" style=\"line-height:10px\">\r\n"
	            		+ "																	<div style=\"max-width: 130px;\"><a href=\"http://example.com\" target=\"_blank\" style=\"outline:none\" tabindex=\"-1\"><img src=\"https://d1oco4z2z1fhwp.cloudfront.net/templates/default/5201/arkalogotemplate.png\" style=\"display: block; height: auto; border: 0; width: 100%;\" width=\"130\" alt=\"Arka Boutique Logo\" title=\"Arka Boutique Logo\" height=\"auto\"></a></div>\r\n"
	            		+ "																</div>\r\n"
	            		+ "															</td>\r\n"
	            		+ "														</tr>\r\n"
	            		+ "													</table>\r\n"
	            		+ "													<div class=\"spacer_block block-4\" style=\"height:155px;line-height:155px;font-size:1px;\">&#8202;</div>\r\n"
	            		+ "													<table class=\"divider_block block-5\" width=\"100%\" border=\"0\" cellpadding=\"10\" cellspacing=\"0\" role=\"presentation\" style=\"mso-table-lspace: 0pt; mso-table-rspace: 0pt;\">\r\n"
	            		+ "														<tr>\r\n"
	            		+ "															<td class=\"pad\">\r\n"
	            		+ "																<div class=\"alignment\" align=\"center\">\r\n"
	            		+ "																	<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" role=\"presentation\" width=\"15%\" style=\"mso-table-lspace: 0pt; mso-table-rspace: 0pt;\">\r\n"
	            		+ "																		<tr>\r\n"
	            		+ "																			<td class=\"divider_inner\" style=\"font-size: 1px; line-height: 1px; border-top: 1px dashed #7DE5E5;\"><span>&#8202;</span></td>\r\n"
	            		+ "																		</tr>\r\n"
	            		+ "																	</table>\r\n"
	            		+ "																</div>\r\n"
	            		+ "															</td>\r\n"
	            		+ "														</tr>\r\n"
	            		+ "													</table>\r\n"
	            		+ "													<table class=\"heading_block block-6\" width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" role=\"presentation\" style=\"mso-table-lspace: 0pt; mso-table-rspace: 0pt;\">\r\n"
	            		+ "														<tr>\r\n"
	            		+ "															<td class=\"pad\" style=\"text-align:center;width:100%;\">\r\n"
	            		+ "																<h2  style=\\\"margin: 0; color: #ffffff; direction: ltr; font-family: 'Oswald', Arial, 'Helvetica Neue', Helvetica, sans-serif; font-size: 86px; font-weight: normal; letter-spacing: normal; line-height: 120%; text-align: center; margin-top: 0; margin-bottom: 0; mso-line-height-alt: 103.2px;\\\">Dear " + u.getFirstname() + ",</h2>"
	            		+ "																<h1 style=\"margin: 0; color: #ffffff; direction: ltr; font-family: 'Oswald', Arial, 'Helvetica Neue', Helvetica, sans-serif; font-size: 86px; font-weight: normal; letter-spacing: normal; line-height: 120%; text-align: center; margin-top: 0; margin-bottom: 0; mso-line-height-alt: 103.2px;\"><strong>THANK YOU FOR YOUR REGISTRATION...!</strong></h1>\r\n"
	            		+ "															</td>\r\n"
	            		+ "														</tr>\r\n"
	            		+ "													</table>\r\n"
	            		+ "													<div class=\"spacer_block block-7 mobile_hide\" style=\"height:70px;line-height:70px;font-size:1px;\">&#8202;</div>\r\n"
	            		+ "													<table class=\"divider_block block-8\" width=\"100%\" border=\"0\" cellpadding=\"10\" cellspacing=\"0\" role=\"presentation\" style=\"mso-table-lspace: 0pt; mso-table-rspace: 0pt;\">\r\n"
	            		+ "														<tr>\r\n"
	            		+ "															<td class=\"pad\">\r\n"
	            		+ "																<div class=\"alignment\" align=\"center\">\r\n"
	            		+ "																	<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" role=\"presentation\" width=\"5%\" style=\"mso-table-lspace: 0pt; mso-table-rspace: 0pt;\">\r\n"
	            		+ "																		<tr>\r\n"
	            		+ "																			<td class=\"divider_inner\" style=\"font-size: 1px; line-height: 1px; border-top: 1px dashed #7DE5E5;\"><span>&#8202;</span></td>\r\n"
	            		+ "																		</tr>\r\n"
	            		+ "																	</table>\r\n"
	            		+ "																</div>\r\n"
	            		+ "															</td>\r\n"
	            		+ "														</tr>\r\n"
	            		+ "													</table>\r\n"
	            		+ "												</td>\r\n"
	            		+ "											</tr>\r\n"
	            		+ "										</tbody>\r\n"
	            		+ "									</table>\r\n"
	            		+ "								</td>\r\n"
	            		+ "							</tr>\r\n"
	            		+ "						</tbody>\r\n"
	            		+ "					</table>\r\n"
	            		+ "					<table class=\"row row-2\" align=\"center\" width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" role=\"presentation\" style=\"mso-table-lspace: 0pt; mso-table-rspace: 0pt; background-color: #07071f;\">\r\n"
	            		+ "						<tbody>\r\n"
	            		+ "							<tr>\r\n"
	            		+ "								<td>\r\n"
	            		+ "									<table class=\"row-content stack\" align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" role=\"presentation\" style=\"mso-table-lspace: 0pt; mso-table-rspace: 0pt; background-color: #060e21; color: #000000; width: 650px; margin: 0 auto;\" width=\"650\">\r\n"
	            		+ "										<tbody>\r\n"
	            		+ "											<tr>\r\n"
	            		+ "												<td class=\"column column-1\" width=\"100%\" style=\"mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; padding-bottom: 5px; padding-top: 5px; vertical-align: top; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;\">\r\n"
	            		+ "													<div class=\"spacer_block block-1\" style=\"height:20px;line-height:20px;font-size:1px;\">&#8202;</div>\r\n"
	            		+ "												</td>\r\n"
	            		+ "											</tr>\r\n"
	            		+ "										</tbody>\r\n"
	            		+ "									</table>\r\n"
	            		+ "								</td>\r\n"
	            		+ "							</tr>\r\n"
	            		+ "						</tbody>\r\n"
	            		+ "					</table>\r\n"
	            		+ "					<table class=\"row row-3\" align=\"center\" width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" role=\"presentation\" style=\"mso-table-lspace: 0pt; mso-table-rspace: 0pt; background-color: #07071f;\">\r\n"
	            		+ "						<tbody>\r\n"
	            		+ "							<tr>\r\n"
	            		+ "								<td>\r\n"
	            		+ "									<table class=\"row-content stack\" align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" role=\"presentation\" style=\"mso-table-lspace: 0pt; mso-table-rspace: 0pt; background-color: #060e21; color: #000000; width: 650px; margin: 0 auto;\" width=\"650\">\r\n"
	            		+ "										<tbody>\r\n"
	            		+ "											<tr>\r\n"
	            		+ "												<td class=\"column column-1\" width=\"100%\" style=\"mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; padding-bottom: 5px; padding-top: 5px; vertical-align: top; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;\">\r\n"
	            		+ "													<div class=\"spacer_block block-1\" style=\"height:30px;line-height:30px;font-size:1px;\">&#8202;</div>\r\n"
	            		+ "												</td>\r\n"
	            		+ "											</tr>\r\n"
	            		+ "										</tbody>\r\n"
	            		+ "									</table>\r\n"
	            		+ "								</td>\r\n"
	            		+ "							</tr>\r\n"
	            		+ "						</tbody>\r\n"
	            		+ "					</table>\r\n"
	            		+ "					<table class=\"row row-4\" align=\"center\" width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" role=\"presentation\" style=\"mso-table-lspace: 0pt; mso-table-rspace: 0pt; background-color: #07071f;\">\r\n"
	            		+ "						<tbody>\r\n"
	            		+ "							<tr>\r\n"
	            		+ "								<td>\r\n"
	            		+ "									<table class=\"row-content stack\" align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" role=\"presentation\" style=\"mso-table-lspace: 0pt; mso-table-rspace: 0pt; background-color: #060e21; color: #000000; width: 650px; margin: 0 auto;\" width=\"650\">\r\n"
	            		+ "										<tbody>\r\n"
	            		+ "											<tr>\r\n"
	            		+ "												<td class=\"column column-1\" width=\"100%\" style=\"mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; padding-bottom: 5px; padding-top: 15px; vertical-align: top; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;\">\r\n"
	            		+ "													<table class=\"image_block block-1\" width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" role=\"presentation\" style=\"mso-table-lspace: 0pt; mso-table-rspace: 0pt;\">\r\n"
	            		+ "														<tr>\r\n"
	            		+ "															<td class=\"pad\" style=\"width:100%;\">\r\n"
	            		+ "																<div class=\"alignment\" align=\"center\" style=\"line-height:10px\">\r\n"
	            		+ "																	<div style=\"max-width: 89px;\"><a href=\"http://example.com\" target=\"_blank\" style=\"outline:none\" tabindex=\"-1\"><img src=\"https://d1oco4z2z1fhwp.cloudfront.net/templates/default/5201/5517d536-0ac6-4a25-a52d-19ae8cbabf79.png\" style=\"display: block; height: auto; border: 0; width: 100%;\" width=\"89\" alt=\"Arka Boutique Logo\" title=\"Arka Boutique Logo\" height=\"auto\"></a></div>\r\n"
	            		+ "																</div>\r\n"
	            		+ "															</td>\r\n"
	            		+ "														</tr>\r\n"
	            		+ "													</table>\r\n"
	            		+ "													<table class=\"social_block block-2\" width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" role=\"presentation\" style=\"mso-table-lspace: 0pt; mso-table-rspace: 0pt;\">\r\n"
	            		+ "														<tr>\r\n"
	            		+ "															<td class=\"pad\" style=\"padding-left:10px;padding-right:10px;padding-top:15px;text-align:center;\">\r\n"
	            		+ "																<div class=\"alignment\" align=\"center\">\r\n"
	            		+ "																	<table class=\"social-table\" width=\"144px\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" role=\"presentation\" style=\"mso-table-lspace: 0pt; mso-table-rspace: 0pt; display: inline-block;\">\r\n"
	            		+ "																		<tr>\r\n"
	            		+ "																			<td style=\"padding:0 2px 0 2px;\"><a href=\"https://www.facebook.com\" target=\"_blank\"><img src=\"https://app-rsrc.getbee.io/public/resources/social-networks-icon-sets/t-only-logo-white/facebook@2x.png\" width=\"32\" height=\"auto\" alt=\"Facebook\" title=\"facebook\" style=\"display: block; height: auto; border: 0;\"></a></td>\r\n"
	            		+ "																			<td style=\"padding:0 2px 0 2px;\"><a href=\"https://www.twitter.com\" target=\"_blank\"><img src=\"https://app-rsrc.getbee.io/public/resources/social-networks-icon-sets/t-only-logo-white/twitter@2x.png\" width=\"32\" height=\"auto\" alt=\"Twitter\" title=\"twitter\" style=\"display: block; height: auto; border: 0;\"></a></td>\r\n"
	            		+ "																			<td style=\"padding:0 2px 0 2px;\"><a href=\"https://www.linkedin.com\" target=\"_blank\"><img src=\"https://app-rsrc.getbee.io/public/resources/social-networks-icon-sets/t-only-logo-white/linkedin@2x.png\" width=\"32\" height=\"auto\" alt=\"Linkedin\" title=\"linkedin\" style=\"display: block; height: auto; border: 0;\"></a></td>\r\n"
	            		+ "																			<td style=\"padding:0 2px 0 2px;\"><a href=\"https://www.instagram.com\" target=\"_blank\"><img src=\"https://app-rsrc.getbee.io/public/resources/social-networks-icon-sets/t-only-logo-white/instagram@2x.png\" width=\"32\" height=\"auto\" alt=\"Instagram\" title=\"instagram\" style=\"display: block; height: auto; border: 0;\"></a></td>\r\n"
	            		+ "																		</tr>\r\n"
	            		+ "																	</table>\r\n"
	            		+ "																</div>\r\n"
	            		+ "															</td>\r\n"
	            		+ "														</tr>\r\n"
	            		+ "													</table>\r\n"
	            		+ "													<table class=\"paragraph_block block-3\" width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" role=\"presentation\" style=\"mso-table-lspace: 0pt; mso-table-rspace: 0pt; word-break: break-word;\">\r\n"
	            		+ "														<tr>\r\n"
	            		+ "															<td class=\"pad\" style=\"padding-left:10px;padding-right:10px;\">\r\n"
	            		+ "																<div style=\"color:#393d47;font-family:'Oswald',Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:14px;line-height:120%;text-align:center;mso-line-height-alt:16.8px;\">\r\n"
	            		+ "																	<p style=\"margin: 0; word-break: break-word;\"><span style=\"color:#ffffff;\">Changed your mind? <a href=\"http://www.example.com\" target=\"_blank\" style=\"text-decoration: underline; color: #ffffff;\" rel=\"noopener\">Unsubscribe</a></span></p>\r\n"
	            		+ "																</div>\r\n"
	            		+ "															</td>\r\n"
	            		+ "														</tr>\r\n"
	            		+ "													</table>\r\n"
	            		+ "												</td>\r\n"
	            		+ "											</tr>\r\n"
	            		+ "										</tbody>\r\n"
	            		+ "									</table>\r\n"
	            		+ "								</td>\r\n"
	            		+ "							</tr>\r\n"
	            		+ "						</tbody>\r\n"
	            		+ "					</table>\r\n"
	            		+ "					<table class=\"row row-5\" align=\"center\" width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" role=\"presentation\" style=\"mso-table-lspace: 0pt; mso-table-rspace: 0pt; background-color: #ffffff;\">\r\n"
	            		+ "						<tbody>\r\n"
	            		+ "							<tr>\r\n"
	            		+ "								<td>\r\n"
	            		+ "									<table class=\"row-content stack\" align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" role=\"presentation\" style=\"mso-table-lspace: 0pt; mso-table-rspace: 0pt; background-color: #ffffff; color: #000000; width: 650px; margin: 0 auto;\" width=\"650\">\r\n"
	            		+ "										<tbody>\r\n"
	            		+ "											<tr>\r\n"
	            		+ "												<td class=\"column column-1\" width=\"100%\" style=\"mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; padding-bottom: 5px; padding-top: 5px; vertical-align: top; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;\">\r\n"
	            		+ "													<table class=\"icons_block block-1\" width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" role=\"presentation\" style=\"mso-table-lspace: 0pt; mso-table-rspace: 0pt; text-align: center;\">\r\n"
	            		+ "														<tr>\r\n"
	            		+ "															<td class=\"pad\" style=\"vertical-align: middle; color: #1e0e4b; font-family: 'Inter', sans-serif; font-size: 15px; padding-bottom: 5px; padding-top: 5px; text-align: center;\">\r\n"
	            		+ "																<table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" role=\"presentation\" style=\"mso-table-lspace: 0pt; mso-table-rspace: 0pt;\">\r\n"
	            		+ "																	<tr>\r\n"
	            		+ "																		<td class=\"alignment\" style=\"vertical-align: middle; text-align: center;\"><!--[if vml]><table align=\"center\" cellpadding=\"0\" cellspacing=\"0\" role=\"presentation\" style=\"display:inline-block;padding-left:0px;padding-right:0px;mso-table-lspace: 0pt;mso-table-rspace: 0pt;\"><![endif]-->\r\n"
	            		+ "																			<!--[if !vml]><!-->\r\n"
	            		+ "																			<table class=\"icons-inner\" style=\"mso-table-lspace: 0pt; mso-table-rspace: 0pt; display: inline-block; margin-right: -4px; padding-left: 0px; padding-right: 0px;\" cellpadding=\"0\" cellspacing=\"0\" role=\"presentation\"><!--<![endif]-->\r\n"
	            		+ "																				<tr>\r\n"
	            		+ "																					<td style=\"vertical-align: middle; text-align: center; padding-top: 5px; padding-bottom: 5px; padding-left: 5px; padding-right: 6px;\"><a href=\"http://designedwithbeefree.com/\" target=\"_blank\" style=\"text-decoration: none;\"><img class=\"icon\" alt=\"Beefree Logo\" src=\"https://d1oco4z2z1fhwp.cloudfront.net/assets/Beefree-logo.png\" height=\"auto\" width=\"34\" align=\"center\" style=\"display: block; height: auto; margin: 0 auto; border: 0;\"></a></td>\r\n"
	            		+ "																					<td style=\"font-family: 'Inter', sans-serif; font-size: 15px; font-weight: undefined; color: #1e0e4b; vertical-align: middle; letter-spacing: undefined; text-align: center;\"><a href=\"http://designedwithbeefree.com/\" target=\"_blank\" style=\"color: #1e0e4b; text-decoration: none;\">Designed with Beefree</a></td>\r\n"
	            		+ "																				</tr>\r\n"
	            		+ "																			</table>\r\n"
	            		+ "																		</td>\r\n"
	            		+ "																	</tr>\r\n"
	            		+ "																</table>\r\n"
	            		+ "															</td>\r\n"
	            		+ "														</tr>\r\n"
	            		+ "													</table>\r\n"
	            		+ "												</td>\r\n"
	            		+ "											</tr>\r\n"
	            		+ "										</tbody>\r\n"
	            		+ "									</table>\r\n"
	            		+ "								</td>\r\n"
	            		+ "							</tr>\r\n"
	            		+ "						</tbody>\r\n"
	            		+ "					</table>\r\n"
	            		+ "				</td>\r\n"
	            		+ "			</tr>\r\n"
	            		+ "		</tbody>\r\n"
	            		+ "	</table><!-- End -->\r\n"
	            		+ "</body>\r\n"
	            		+ "\r\n"
	            		+ "</html>"); // Set the HTML message
	            mailservice.sendmail(u.getEmail(), email);
	            cl.save(u);
	            return "redirect:/login"; // Redirect to the login page upon successful registration
	        }
	    }
}


